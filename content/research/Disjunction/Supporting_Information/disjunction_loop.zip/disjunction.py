#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2021.1.4),
    on Thu May 27 10:24:56 2021
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

from psychopy import locale_setup
from psychopy import prefs
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard

import locale, time
locale.setlocale(locale.LC_ALL, 'en')
time.strftime('%a')

# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
psychopyVersion = '2021.1.4'
expName = 'disjunction'  # from the Builder filename that created this script
expInfo = {'participant': '', 'session': '001'}
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='/Users/wangmeng/Desktop/disjunction_1/disjunction.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run after the window creation

# Setup the Window
win = visual.Window(
    size=[1440, 900], fullscr=True, screen=0, 
    winType='pyglet', allowGUI=False, allowStencil=False,
    monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
    blendMode='avg', useFBO=True, 
    units='height')
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard()

# Initialize components for Routine "instr"
instrClock = core.Clock()
TextInstr = visual.TextStim(win=win, name='TextInstr',
    text='欢迎来到本次实验！\n实验过程中您将听到一些句子，每个句子结束后您需要回答一个问题，请仔细听。\n按空格键开始正式实验。',
    font='Open Sans',
    pos=(0, 0), height=0.001, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
KeyInstr = keyboard.Keyboard()

# Initialize components for Routine "trial_1"
trial_1Clock = core.Clock()
SoundTrial_1 = sound.Sound('stimuli/GroupA/b1/200ms_编辑收到了图片或文案.wav', secs=-1, stereo=True, hamming=True,
    name='SoundTrial_1')
SoundTrial_1.setVolume(1.0)
TextTrial_1 = visual.TextStim(win=win, name='TextTrial_1',
    text='+',
    font='Open Sans',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);

# Initialize components for Routine "resp_1"
resp_1Clock = core.Clock()
TextResp_1 = visual.TextStim(win=win, name='TextResp_1',
    text='您刚刚听到的句子中，最后一个词是否有生命？\n',
    font='Open Sans',
    pos=(0, 0), height=0.001, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
TextResp_2 = visual.TextStim(win=win, name='TextResp_2',
    text='有生命1，无生命2',
    font='Open Sans',
    pos=(0, 0), height=0.001, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
KeyResp_1 = keyboard.Keyboard()

# Initialize components for Routine "break_1"
break_1Clock = core.Clock()
TextBreak_1 = visual.TextStim(win=win, name='TextBreak_1',
    text='+',
    font='Open Sans',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "bye"
byeClock = core.Clock()
textBye = visual.TextStim(win=win, name='textBye',
    text='实验结束，感谢您的参与！',
    font='Open Sans',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# ------Prepare to start Routine "instr"-------
continueRoutine = True
# update component parameters for each repeat
KeyInstr.keys = []
KeyInstr.rt = []
_KeyInstr_allKeys = []
# keep track of which components have finished
instrComponents = [TextInstr, KeyInstr]
for thisComponent in instrComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
instrClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "instr"-------
while continueRoutine:
    # get current time
    t = instrClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=instrClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *TextInstr* updates
    if TextInstr.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        TextInstr.frameNStart = frameN  # exact frame index
        TextInstr.tStart = t  # local t and not account for scr refresh
        TextInstr.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(TextInstr, 'tStartRefresh')  # time at next scr refresh
        TextInstr.setAutoDraw(True)
    
    # *KeyInstr* updates
    waitOnFlip = False
    if KeyInstr.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        KeyInstr.frameNStart = frameN  # exact frame index
        KeyInstr.tStart = t  # local t and not account for scr refresh
        KeyInstr.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(KeyInstr, 'tStartRefresh')  # time at next scr refresh
        KeyInstr.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(KeyInstr.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(KeyInstr.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if KeyInstr.status == STARTED and not waitOnFlip:
        theseKeys = KeyInstr.getKeys(keyList=['space'], waitRelease=False)
        _KeyInstr_allKeys.extend(theseKeys)
        if len(_KeyInstr_allKeys):
            KeyInstr.keys = _KeyInstr_allKeys[-1].name  # just the last key pressed
            KeyInstr.rt = _KeyInstr_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instrComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "instr"-------
for thisComponent in instrComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('TextInstr.started', TextInstr.tStartRefresh)
thisExp.addData('TextInstr.stopped', TextInstr.tStopRefresh)
# check responses
if KeyInstr.keys in ['', [], None]:  # No response was made
    KeyInstr.keys = None
thisExp.addData('KeyInstr.keys',KeyInstr.keys)
if KeyInstr.keys != None:  # we had a response
    thisExp.addData('KeyInstr.rt', KeyInstr.rt)
thisExp.addData('KeyInstr.started', KeyInstr.tStartRefresh)
thisExp.addData('KeyInstr.stopped', KeyInstr.tStopRefresh)
thisExp.nextEntry()
# the Routine "instr" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "trial_1"-------
continueRoutine = True
# update component parameters for each repeat
SoundTrial_1.setSound('stimuli/GroupA/b1/200ms_编辑收到了图片或文案.wav', hamming=True)
SoundTrial_1.setVolume(1.0, log=False)
# keep track of which components have finished
trial_1Components = [SoundTrial_1, TextTrial_1]
for thisComponent in trial_1Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
trial_1Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "trial_1"-------
while continueRoutine:
    # get current time
    t = trial_1Clock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=trial_1Clock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    # start/stop SoundTrial_1
    if SoundTrial_1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        SoundTrial_1.frameNStart = frameN  # exact frame index
        SoundTrial_1.tStart = t  # local t and not account for scr refresh
        SoundTrial_1.tStartRefresh = tThisFlipGlobal  # on global time
        SoundTrial_1.play(when=win)  # sync with win flip
    
    # *TextTrial_1* updates
    if TextTrial_1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        TextTrial_1.frameNStart = frameN  # exact frame index
        TextTrial_1.tStart = t  # local t and not account for scr refresh
        TextTrial_1.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(TextTrial_1, 'tStartRefresh')  # time at next scr refresh
        TextTrial_1.setAutoDraw(True)
    if TextTrial_1.status == STARTED:
        # is it time to stop? (based on local clock)
        if tThisFlip > SoundTrial_1.status==FINISHED-frameTolerance:
            # keep track of stop time/frame for later
            TextTrial_1.tStop = t  # not accounting for scr refresh
            TextTrial_1.frameNStop = frameN  # exact frame index
            win.timeOnFlip(TextTrial_1, 'tStopRefresh')  # time at next scr refresh
            TextTrial_1.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in trial_1Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "trial_1"-------
for thisComponent in trial_1Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
SoundTrial_1.stop()  # ensure sound has stopped at end of routine
thisExp.addData('SoundTrial_1.started', SoundTrial_1.tStartRefresh)
thisExp.addData('SoundTrial_1.stopped', SoundTrial_1.tStopRefresh)
thisExp.addData('TextTrial_1.started', TextTrial_1.tStartRefresh)
thisExp.addData('TextTrial_1.stopped', TextTrial_1.tStopRefresh)
# the Routine "trial_1" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "resp_1"-------
continueRoutine = True
# update component parameters for each repeat
KeyResp_1.keys = []
KeyResp_1.rt = []
_KeyResp_1_allKeys = []
# keep track of which components have finished
resp_1Components = [TextResp_1, TextResp_2, KeyResp_1]
for thisComponent in resp_1Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
resp_1Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "resp_1"-------
while continueRoutine:
    # get current time
    t = resp_1Clock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=resp_1Clock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *TextResp_1* updates
    if TextResp_1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        TextResp_1.frameNStart = frameN  # exact frame index
        TextResp_1.tStart = t  # local t and not account for scr refresh
        TextResp_1.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(TextResp_1, 'tStartRefresh')  # time at next scr refresh
        TextResp_1.setAutoDraw(True)
    if TextResp_1.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > TextResp_1.tStartRefresh + 2.0-frameTolerance:
            # keep track of stop time/frame for later
            TextResp_1.tStop = t  # not accounting for scr refresh
            TextResp_1.frameNStop = frameN  # exact frame index
            win.timeOnFlip(TextResp_1, 'tStopRefresh')  # time at next scr refresh
            TextResp_1.setAutoDraw(False)
    
    # *TextResp_2* updates
    if TextResp_2.status == NOT_STARTED and tThisFlip >= TextResp_1.status==FINISHED-frameTolerance:
        # keep track of start time/frame for later
        TextResp_2.frameNStart = frameN  # exact frame index
        TextResp_2.tStart = t  # local t and not account for scr refresh
        TextResp_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(TextResp_2, 'tStartRefresh')  # time at next scr refresh
        TextResp_2.setAutoDraw(True)
    if TextResp_2.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > TextResp_2.tStartRefresh + 2.0-frameTolerance:
            # keep track of stop time/frame for later
            TextResp_2.tStop = t  # not accounting for scr refresh
            TextResp_2.frameNStop = frameN  # exact frame index
            win.timeOnFlip(TextResp_2, 'tStopRefresh')  # time at next scr refresh
            TextResp_2.setAutoDraw(False)
    
    # *KeyResp_1* updates
    waitOnFlip = False
    if KeyResp_1.status == NOT_STARTED and tThisFlip >= $TextResp_2.status==STARTED-frameTolerance:
        # keep track of start time/frame for later
        KeyResp_1.frameNStart = frameN  # exact frame index
        KeyResp_1.tStart = t  # local t and not account for scr refresh
        KeyResp_1.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(KeyResp_1, 'tStartRefresh')  # time at next scr refresh
        KeyResp_1.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(KeyResp_1.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(KeyResp_1.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if KeyResp_1.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > KeyResp_1.tStartRefresh + 2.0-frameTolerance:
            # keep track of stop time/frame for later
            KeyResp_1.tStop = t  # not accounting for scr refresh
            KeyResp_1.frameNStop = frameN  # exact frame index
            win.timeOnFlip(KeyResp_1, 'tStopRefresh')  # time at next scr refresh
            KeyResp_1.status = FINISHED
    if KeyResp_1.status == STARTED and not waitOnFlip:
        theseKeys = KeyResp_1.getKeys(keyList=['1', '2'], waitRelease=False)
        _KeyResp_1_allKeys.extend(theseKeys)
        if len(_KeyResp_1_allKeys):
            KeyResp_1.keys = _KeyResp_1_allKeys[-1].name  # just the last key pressed
            KeyResp_1.rt = _KeyResp_1_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in resp_1Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "resp_1"-------
for thisComponent in resp_1Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('TextResp_1.started', TextResp_1.tStartRefresh)
thisExp.addData('TextResp_1.stopped', TextResp_1.tStopRefresh)
thisExp.addData('TextResp_2.started', TextResp_2.tStartRefresh)
thisExp.addData('TextResp_2.stopped', TextResp_2.tStopRefresh)
# check responses
if KeyResp_1.keys in ['', [], None]:  # No response was made
    KeyResp_1.keys = None
thisExp.addData('KeyResp_1.keys',KeyResp_1.keys)
if KeyResp_1.keys != None:  # we had a response
    thisExp.addData('KeyResp_1.rt', KeyResp_1.rt)
thisExp.addData('KeyResp_1.started', KeyResp_1.tStartRefresh)
thisExp.addData('KeyResp_1.stopped', KeyResp_1.tStopRefresh)
thisExp.nextEntry()
# the Routine "resp_1" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "break_1"-------
continueRoutine = True
routineTimer.add(2.000000)
# update component parameters for each repeat
# keep track of which components have finished
break_1Components = [TextBreak_1]
for thisComponent in break_1Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
break_1Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "break_1"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = break_1Clock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=break_1Clock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *TextBreak_1* updates
    if TextBreak_1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        TextBreak_1.frameNStart = frameN  # exact frame index
        TextBreak_1.tStart = t  # local t and not account for scr refresh
        TextBreak_1.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(TextBreak_1, 'tStartRefresh')  # time at next scr refresh
        TextBreak_1.setAutoDraw(True)
    if TextBreak_1.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > TextBreak_1.tStartRefresh + 2.0-frameTolerance:
            # keep track of stop time/frame for later
            TextBreak_1.tStop = t  # not accounting for scr refresh
            TextBreak_1.frameNStop = frameN  # exact frame index
            win.timeOnFlip(TextBreak_1, 'tStopRefresh')  # time at next scr refresh
            TextBreak_1.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in break_1Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "break_1"-------
for thisComponent in break_1Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('TextBreak_1.started', TextBreak_1.tStartRefresh)
thisExp.addData('TextBreak_1.stopped', TextBreak_1.tStopRefresh)

# ------Prepare to start Routine "bye"-------
continueRoutine = True
# update component parameters for each repeat
# keep track of which components have finished
byeComponents = [textBye]
for thisComponent in byeComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
byeClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "bye"-------
while continueRoutine:
    # get current time
    t = byeClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=byeClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *textBye* updates
    if textBye.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        textBye.frameNStart = frameN  # exact frame index
        textBye.tStart = t  # local t and not account for scr refresh
        textBye.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(textBye, 'tStartRefresh')  # time at next scr refresh
        textBye.setAutoDraw(True)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in byeComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "bye"-------
for thisComponent in byeComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('textBye.started', textBye.tStartRefresh)
thisExp.addData('textBye.stopped', textBye.tStopRefresh)
# the Routine "bye" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv', delim='auto')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
