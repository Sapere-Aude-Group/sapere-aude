﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2021.2.0),
    on August 09, 2021, at 18:58
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

from __future__ import absolute_import, division

from psychopy import locale_setup
from psychopy import prefs
prefs.hardware['audioLib'] = 'pyo'
prefs.hardware['audioLatencyMode'] = '4'
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, parallel
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard



# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
psychopyVersion = '2021.2.0'
expName = 'disjunction'  # from the Builder filename that created this script
expInfo = {'participant': '001', 'group': 'A', 'name': '', 'gender': ''}
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='F:\\disjunction_lab-loop正常版\\disjunction_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.DEBUG)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run after the window creation

# Setup the Window
win = visual.Window(
    size=[1920, 1080], fullscr=True, screen=0, 
    winType='pyglet', allowGUI=False, allowStencil=False,
    monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
    blendMode='avg', useFBO=True, 
    units='height')
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# Setup eyetracking
ioDevice = ioConfig = ioSession = ioServer = eyetracker = None

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard()

# Initialize components for Routine "instr"
instrClock = core.Clock()
imageInstr = visual.ImageStim(
    win=win,
    name='imageInstr', 
    image='instr.png', mask=None,
    ori=0.0, pos=(0,0), size=None,
    color=[1,1,1], colorSpace='rgb', opacity=1.0,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
keyInstr = keyboard.Keyboard()

# Initialize components for Routine "baseline_2"
baseline_2Clock = core.Clock()
polygonBaseline = visual.ShapeStim(
    win=win, name='polygonBaseline', vertices='cross',units='deg', 
    size=(1, 1),
    ori=0.0, pos=(0, 0),
    lineWidth=1.0,     colorSpace='rgb',  lineColor=[1,1,1], fillColor=[1,1,1],
    opacity=1.0, depth=0.0, interpolate=True)
p_port = parallel.ParallelPort(address='0xD010')

# Initialize components for Routine "instr2"
instr2Clock = core.Clock()
imageInstr2 = visual.ImageStim(
    win=win,
    name='imageInstr2', 
    image='instr2.png', mask=None,
    ori=0.0, pos=(0, 0), size=None,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
keyInstr2 = keyboard.Keyboard()

# Initialize components for Routine "trial_1"
trial_1Clock = core.Clock()
SoundTrial_1 = sound.Sound('A', secs=-1, stereo=True, hamming=True,
    name='SoundTrial_1')
SoundTrial_1.setVolume(1.0)
fixation_1 = visual.ShapeStim(
    win=win, name='fixation_1', vertices='cross',units='deg', 
    size=(1, 1),
    ori=0.0, pos=(0, 0),
    lineWidth=1.0,     colorSpace='rgb',  lineColor=[1,1,1], fillColor=[1,1,1],
    opacity=1.0, depth=-1.0, interpolate=True)
textResp_1 = visual.TextStim(win=win, name='textResp_1',
    text='您刚刚听到的句子中，\n最后一个词是否有生命？',
    font='STSong',
    pos=(0, 0), height=0.06, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=1.0, 
    languageStyle='LTR',
    depth=-2.0);
textResp_2 = visual.TextStim(win=win, name='textResp_2',
    text='有生命"←" ，无生命"→"',
    font='STSong',
    pos=(0, 0), height=0.06, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=1.0, 
    languageStyle='LTR',
    depth=-3.0);
keyResp_1 = keyboard.Keyboard()
p_portItem = parallel.ParallelPort(address='0xD010')
p_portN2 = parallel.ParallelPort(address='0xD010')
p_portC = parallel.ParallelPort(address='0xD010')
p_portN3 = parallel.ParallelPort(address='0xD010')
p_portType = parallel.ParallelPort(address='0xD010')
p_port_2 = parallel.ParallelPort(address='0xD010')

# Initialize components for Routine "ITI"
ITIClock = core.Clock()
fixationBreak = visual.ShapeStim(
    win=win, name='fixationBreak', vertices='cross',units='deg', 
    size=(1, 1),
    ori=0.0, pos=(0, 0),
    lineWidth=1.0,     colorSpace='rgb',  lineColor=[1,1,1], fillColor=[1,1,1],
    opacity=1.0, depth=0.0, interpolate=True)

# Initialize components for Routine "break_2"
break_2Clock = core.Clock()
text_3 = visual.TextStim(win=win, name='text_3',
    text='现在您可以休息30s',
    font='STSong',
    pos=(0, 0), height=0.06, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=1.0, 
    languageStyle='LTR',
    depth=0.0);
text_4 = visual.TextStim(win=win, name='text_4',
    text='实验继续',
    font='STSong',
    pos=(0, 0), height=0.06, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=1.0, 
    languageStyle='LTR',
    depth=-1.0);

# Initialize components for Routine "bye"
byeClock = core.Clock()
textBye = visual.TextStim(win=win, name='textBye',
    text='实验结束，感谢您的参与！',
    font='STSong',
    pos=(0, 0), height=0.06, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=1.0, 
    languageStyle='LTR',
    depth=0.0);

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# ------Prepare to start Routine "instr"-------
continueRoutine = True
# update component parameters for each repeat
keyInstr.keys = []
keyInstr.rt = []
_keyInstr_allKeys = []
# keep track of which components have finished
instrComponents = [imageInstr, keyInstr]
for thisComponent in instrComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
instrClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "instr"-------
while continueRoutine:
    # get current time
    t = instrClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=instrClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *imageInstr* updates
    if imageInstr.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        imageInstr.frameNStart = frameN  # exact frame index
        imageInstr.tStart = t  # local t and not account for scr refresh
        imageInstr.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(imageInstr, 'tStartRefresh')  # time at next scr refresh
        imageInstr.setAutoDraw(True)
    
    # *keyInstr* updates
    waitOnFlip = False
    if keyInstr.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        keyInstr.frameNStart = frameN  # exact frame index
        keyInstr.tStart = t  # local t and not account for scr refresh
        keyInstr.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(keyInstr, 'tStartRefresh')  # time at next scr refresh
        keyInstr.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(keyInstr.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(keyInstr.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if keyInstr.status == STARTED and not waitOnFlip:
        theseKeys = keyInstr.getKeys(keyList=['space'], waitRelease=False)
        _keyInstr_allKeys.extend(theseKeys)
        if len(_keyInstr_allKeys):
            keyInstr.keys = _keyInstr_allKeys[-1].name  # just the last key pressed
            keyInstr.rt = _keyInstr_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instrComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "instr"-------
for thisComponent in instrComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('imageInstr.started', imageInstr.tStartRefresh)
thisExp.addData('imageInstr.stopped', imageInstr.tStopRefresh)
# check responses
if keyInstr.keys in ['', [], None]:  # No response was made
    keyInstr.keys = None
thisExp.addData('keyInstr.keys',keyInstr.keys)
if keyInstr.keys != None:  # we had a response
    thisExp.addData('keyInstr.rt', keyInstr.rt)
thisExp.addData('keyInstr.started', keyInstr.tStartRefresh)
thisExp.addData('keyInstr.stopped', keyInstr.tStopRefresh)
thisExp.nextEntry()
# the Routine "instr" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "baseline_2"-------
continueRoutine = True
# update component parameters for each repeat
# keep track of which components have finished
baseline_2Components = [polygonBaseline, p_port]
for thisComponent in baseline_2Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
baseline_2Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "baseline_2"-------
while continueRoutine:
    # get current time
    t = baseline_2Clock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=baseline_2Clock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *polygonBaseline* updates
    if polygonBaseline.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        polygonBaseline.frameNStart = frameN  # exact frame index
        polygonBaseline.tStart = t  # local t and not account for scr refresh
        polygonBaseline.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(polygonBaseline, 'tStartRefresh')  # time at next scr refresh
        polygonBaseline.setAutoDraw(True)
    if polygonBaseline.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > polygonBaseline.tStartRefresh + 1.0-frameTolerance:
            # keep track of stop time/frame for later
            polygonBaseline.tStop = t  # not accounting for scr refresh
            polygonBaseline.frameNStop = frameN  # exact frame index
            win.timeOnFlip(polygonBaseline, 'tStopRefresh')  # time at next scr refresh
            polygonBaseline.setAutoDraw(False)
    # *p_port* updates
    if p_port.status == NOT_STARTED and polygonBaseline.status==STARTED:
        # keep track of start time/frame for later
        p_port.frameNStart = frameN  # exact frame index
        p_port.tStart = t  # local t and not account for scr refresh
        p_port.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(p_port, 'tStartRefresh')  # time at next scr refresh
        p_port.status = STARTED
        p_port.setData(int(200))
    if p_port.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > p_port.tStartRefresh + 0.01-frameTolerance:
            # keep track of stop time/frame for later
            p_port.tStop = t  # not accounting for scr refresh
            p_port.frameNStop = frameN  # exact frame index
            win.timeOnFlip(p_port, 'tStopRefresh')  # time at next scr refresh
            p_port.status = FINISHED
            p_port.setData(int(0))
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in baseline_2Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "baseline_2"-------
for thisComponent in baseline_2Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('polygonBaseline.started', polygonBaseline.tStartRefresh)
thisExp.addData('polygonBaseline.stopped', polygonBaseline.tStopRefresh)
if p_port.status == STARTED:
    p_port.setData(int(0))
thisExp.addData('p_port.started', p_port.tStart)
thisExp.addData('p_port.stopped', p_port.tStop)
# the Routine "baseline_2" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "instr2"-------
continueRoutine = True
# update component parameters for each repeat
keyInstr2.keys = []
keyInstr2.rt = []
_keyInstr2_allKeys = []
# keep track of which components have finished
instr2Components = [imageInstr2, keyInstr2]
for thisComponent in instr2Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
instr2Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "instr2"-------
while continueRoutine:
    # get current time
    t = instr2Clock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=instr2Clock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *imageInstr2* updates
    if imageInstr2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        imageInstr2.frameNStart = frameN  # exact frame index
        imageInstr2.tStart = t  # local t and not account for scr refresh
        imageInstr2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(imageInstr2, 'tStartRefresh')  # time at next scr refresh
        imageInstr2.setAutoDraw(True)
    
    # *keyInstr2* updates
    waitOnFlip = False
    if keyInstr2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        keyInstr2.frameNStart = frameN  # exact frame index
        keyInstr2.tStart = t  # local t and not account for scr refresh
        keyInstr2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(keyInstr2, 'tStartRefresh')  # time at next scr refresh
        keyInstr2.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(keyInstr2.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(keyInstr2.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if keyInstr2.status == STARTED and not waitOnFlip:
        theseKeys = keyInstr2.getKeys(keyList=['space'], waitRelease=False)
        _keyInstr2_allKeys.extend(theseKeys)
        if len(_keyInstr2_allKeys):
            keyInstr2.keys = _keyInstr2_allKeys[-1].name  # just the last key pressed
            keyInstr2.rt = _keyInstr2_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instr2Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "instr2"-------
for thisComponent in instr2Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('imageInstr2.started', imageInstr2.tStartRefresh)
thisExp.addData('imageInstr2.stopped', imageInstr2.tStopRefresh)
# check responses
if keyInstr2.keys in ['', [], None]:  # No response was made
    keyInstr2.keys = None
thisExp.addData('keyInstr2.keys',keyInstr2.keys)
if keyInstr2.keys != None:  # we had a response
    thisExp.addData('keyInstr2.rt', keyInstr2.rt)
thisExp.addData('keyInstr2.started', keyInstr2.tStartRefresh)
thisExp.addData('keyInstr2.stopped', keyInstr2.tStopRefresh)
thisExp.nextEntry()
# the Routine "instr2" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
blockorder = data.TrialHandler(nReps=1.0, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions("group{}.xlsx".format(expInfo['group'])),
    seed=None, name='blockorder')
thisExp.addLoop(blockorder)  # add the loop to the experiment
thisBlockorder = blockorder.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisBlockorder.rgb)
if thisBlockorder != None:
    for paramName in thisBlockorder:
        exec('{} = thisBlockorder[paramName]'.format(paramName))

for thisBlockorder in blockorder:
    currentLoop = blockorder
    # abbreviate parameter names if possible (e.g. rgb = thisBlockorder.rgb)
    if thisBlockorder != None:
        for paramName in thisBlockorder:
            exec('{} = thisBlockorder[paramName]'.format(paramName))
    
    # set up handler to look after randomisation of conditions etc
    trialsorder = data.TrialHandler(nReps=1.0, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions(blockcondition + '.xlsx'),
        seed=None, name='trialsorder')
    thisExp.addLoop(trialsorder)  # add the loop to the experiment
    thisTrialsorder = trialsorder.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrialsorder.rgb)
    if thisTrialsorder != None:
        for paramName in thisTrialsorder:
            exec('{} = thisTrialsorder[paramName]'.format(paramName))
    
    for thisTrialsorder in trialsorder:
        currentLoop = trialsorder
        # abbreviate parameter names if possible (e.g. rgb = thisTrialsorder.rgb)
        if thisTrialsorder != None:
            for paramName in thisTrialsorder:
                exec('{} = thisTrialsorder[paramName]'.format(paramName))
        
        # ------Prepare to start Routine "trial_1"-------
        continueRoutine = True
        # update component parameters for each repeat
        SoundTrial_1.setSound(soundfile, hamming=True)
        SoundTrial_1.setVolume(1.0, log=False)
        keyResp_1.keys = []
        keyResp_1.rt = []
        _keyResp_1_allKeys = []
        # keep track of which components have finished
        trial_1Components = [SoundTrial_1, fixation_1, textResp_1, textResp_2, keyResp_1, p_portItem, p_portN2, p_portC, p_portN3, p_portType, p_port_2]
        for thisComponent in trial_1Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        trial_1Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        
        # -------Run Routine "trial_1"-------
        while continueRoutine:
            # get current time
            t = trial_1Clock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=trial_1Clock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            # start/stop SoundTrial_1
            if SoundTrial_1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                SoundTrial_1.frameNStart = frameN  # exact frame index
                SoundTrial_1.tStart = t  # local t and not account for scr refresh
                SoundTrial_1.tStartRefresh = tThisFlipGlobal  # on global time
                SoundTrial_1.play(when=win)  # sync with win flip
            
            # *fixation_1* updates
            if fixation_1.status == NOT_STARTED and SoundTrial_1.status==STARTED:
                # keep track of start time/frame for later
                fixation_1.frameNStart = frameN  # exact frame index
                fixation_1.tStart = t  # local t and not account for scr refresh
                fixation_1.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(fixation_1, 'tStartRefresh')  # time at next scr refresh
                fixation_1.setAutoDraw(True)
            if fixation_1.status == STARTED:
                if bool(SoundTrial_1.status==FINISHED):
                    # keep track of stop time/frame for later
                    fixation_1.tStop = t  # not accounting for scr refresh
                    fixation_1.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(fixation_1, 'tStopRefresh')  # time at next scr refresh
                    fixation_1.setAutoDraw(False)
            
            # *textResp_1* updates
            if textResp_1.status == NOT_STARTED and SoundTrial_1.status==FINISHED:
                # keep track of start time/frame for later
                textResp_1.frameNStart = frameN  # exact frame index
                textResp_1.tStart = t  # local t and not account for scr refresh
                textResp_1.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(textResp_1, 'tStartRefresh')  # time at next scr refresh
                textResp_1.setAutoDraw(True)
            if textResp_1.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > textResp_1.tStartRefresh + 2.0-frameTolerance:
                    # keep track of stop time/frame for later
                    textResp_1.tStop = t  # not accounting for scr refresh
                    textResp_1.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(textResp_1, 'tStopRefresh')  # time at next scr refresh
                    textResp_1.setAutoDraw(False)
            
            # *textResp_2* updates
            if textResp_2.status == NOT_STARTED and textResp_1.status==FINISHED:
                # keep track of start time/frame for later
                textResp_2.frameNStart = frameN  # exact frame index
                textResp_2.tStart = t  # local t and not account for scr refresh
                textResp_2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(textResp_2, 'tStartRefresh')  # time at next scr refresh
                textResp_2.setAutoDraw(True)
            if textResp_2.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > textResp_2.tStartRefresh + 2.0-frameTolerance:
                    # keep track of stop time/frame for later
                    textResp_2.tStop = t  # not accounting for scr refresh
                    textResp_2.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(textResp_2, 'tStopRefresh')  # time at next scr refresh
                    textResp_2.setAutoDraw(False)
            
            # *keyResp_1* updates
            waitOnFlip = False
            if keyResp_1.status == NOT_STARTED and textResp_2.status==STARTED:
                # keep track of start time/frame for later
                keyResp_1.frameNStart = frameN  # exact frame index
                keyResp_1.tStart = t  # local t and not account for scr refresh
                keyResp_1.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(keyResp_1, 'tStartRefresh')  # time at next scr refresh
                keyResp_1.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(keyResp_1.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(keyResp_1.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if keyResp_1.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > keyResp_1.tStartRefresh + 2.0-frameTolerance:
                    # keep track of stop time/frame for later
                    keyResp_1.tStop = t  # not accounting for scr refresh
                    keyResp_1.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(keyResp_1, 'tStopRefresh')  # time at next scr refresh
                    keyResp_1.status = FINISHED
            if keyResp_1.status == STARTED and not waitOnFlip:
                theseKeys = keyResp_1.getKeys(keyList=['left', 'right'], waitRelease=False)
                _keyResp_1_allKeys.extend(theseKeys)
                if len(_keyResp_1_allKeys):
                    keyResp_1.keys = _keyResp_1_allKeys[-1].name  # just the last key pressed
                    keyResp_1.rt = _keyResp_1_allKeys[-1].rt
                    # a response ends the routine
                    continueRoutine = False
            # *p_portItem* updates
            if p_portItem.status == NOT_STARTED and t >= V_Onset-frameTolerance:
                # keep track of start time/frame for later
                p_portItem.frameNStart = frameN  # exact frame index
                p_portItem.tStart = t  # local t and not account for scr refresh
                p_portItem.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(p_portItem, 'tStartRefresh')  # time at next scr refresh
                p_portItem.status = STARTED
                p_portItem.setData(int(ItemTrigger))
            if p_portItem.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > p_portItem.tStartRefresh + 0.01-frameTolerance:
                    # keep track of stop time/frame for later
                    p_portItem.tStop = t  # not accounting for scr refresh
                    p_portItem.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(p_portItem, 'tStopRefresh')  # time at next scr refresh
                    p_portItem.status = FINISHED
                    p_portItem.setData(int(0))
            # *p_portN2* updates
            if p_portN2.status == NOT_STARTED and t >= N2_Onset-frameTolerance:
                # keep track of start time/frame for later
                p_portN2.frameNStart = frameN  # exact frame index
                p_portN2.tStart = t  # local t and not account for scr refresh
                p_portN2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(p_portN2, 'tStartRefresh')  # time at next scr refresh
                p_portN2.status = STARTED
                p_portN2.setData(int(202))
            if p_portN2.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > p_portN2.tStartRefresh + 0.01-frameTolerance:
                    # keep track of stop time/frame for later
                    p_portN2.tStop = t  # not accounting for scr refresh
                    p_portN2.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(p_portN2, 'tStopRefresh')  # time at next scr refresh
                    p_portN2.status = FINISHED
                    p_portN2.setData(int(0))
            # *p_portC* updates
            if p_portC.status == NOT_STARTED and t >= Connective_Onset-frameTolerance:
                # keep track of start time/frame for later
                p_portC.frameNStart = frameN  # exact frame index
                p_portC.tStart = t  # local t and not account for scr refresh
                p_portC.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(p_portC, 'tStartRefresh')  # time at next scr refresh
                p_portC.status = STARTED
                p_portC.setData(int(203))
            if p_portC.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > p_portC.tStartRefresh + 0.01-frameTolerance:
                    # keep track of stop time/frame for later
                    p_portC.tStop = t  # not accounting for scr refresh
                    p_portC.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(p_portC, 'tStopRefresh')  # time at next scr refresh
                    p_portC.status = FINISHED
                    p_portC.setData(int(0))
            # *p_portN3* updates
            if p_portN3.status == NOT_STARTED and t >= N3_Onset-frameTolerance:
                # keep track of start time/frame for later
                p_portN3.frameNStart = frameN  # exact frame index
                p_portN3.tStart = t  # local t and not account for scr refresh
                p_portN3.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(p_portN3, 'tStartRefresh')  # time at next scr refresh
                p_portN3.status = STARTED
                p_portN3.setData(int(204))
            if p_portN3.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > p_portN3.tStartRefresh + 0.01-frameTolerance:
                    # keep track of stop time/frame for later
                    p_portN3.tStop = t  # not accounting for scr refresh
                    p_portN3.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(p_portN3, 'tStopRefresh')  # time at next scr refresh
                    p_portN3.status = FINISHED
                    p_portN3.setData(int(0))
            # *p_portType* updates
            if p_portType.status == NOT_STARTED and t >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                p_portType.frameNStart = frameN  # exact frame index
                p_portType.tStart = t  # local t and not account for scr refresh
                p_portType.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(p_portType, 'tStartRefresh')  # time at next scr refresh
                p_portType.status = STARTED
                p_portType.setData(int(Typetrigger))
            if p_portType.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > p_portType.tStartRefresh + 0.01-frameTolerance:
                    # keep track of stop time/frame for later
                    p_portType.tStop = t  # not accounting for scr refresh
                    p_portType.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(p_portType, 'tStopRefresh')  # time at next scr refresh
                    p_portType.status = FINISHED
                    p_portType.setData(int(0))
            # *p_port_2* updates
            if p_port_2.status == NOT_STARTED and textResp_1.status==STARTED:
                # keep track of start time/frame for later
                p_port_2.frameNStart = frameN  # exact frame index
                p_port_2.tStart = t  # local t and not account for scr refresh
                p_port_2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(p_port_2, 'tStartRefresh')  # time at next scr refresh
                p_port_2.status = STARTED
                win.callOnFlip(p_port_2.setData, int(255))
            if p_port_2.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > p_port_2.tStartRefresh + 0.01-frameTolerance:
                    # keep track of stop time/frame for later
                    p_port_2.tStop = t  # not accounting for scr refresh
                    p_port_2.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(p_port_2, 'tStopRefresh')  # time at next scr refresh
                    p_port_2.status = FINISHED
                    win.callOnFlip(p_port_2.setData, int(0))
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in trial_1Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "trial_1"-------
        for thisComponent in trial_1Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        SoundTrial_1.stop()  # ensure sound has stopped at end of routine
        trialsorder.addData('SoundTrial_1.started', SoundTrial_1.tStartRefresh)
        trialsorder.addData('SoundTrial_1.stopped', SoundTrial_1.tStopRefresh)
        trialsorder.addData('fixation_1.started', fixation_1.tStartRefresh)
        trialsorder.addData('fixation_1.stopped', fixation_1.tStopRefresh)
        trialsorder.addData('textResp_1.started', textResp_1.tStartRefresh)
        trialsorder.addData('textResp_1.stopped', textResp_1.tStopRefresh)
        trialsorder.addData('textResp_2.started', textResp_2.tStartRefresh)
        trialsorder.addData('textResp_2.stopped', textResp_2.tStopRefresh)
        # check responses
        if keyResp_1.keys in ['', [], None]:  # No response was made
            keyResp_1.keys = None
        trialsorder.addData('keyResp_1.keys',keyResp_1.keys)
        if keyResp_1.keys != None:  # we had a response
            trialsorder.addData('keyResp_1.rt', keyResp_1.rt)
        trialsorder.addData('keyResp_1.started', keyResp_1.tStartRefresh)
        trialsorder.addData('keyResp_1.stopped', keyResp_1.tStopRefresh)
        if p_portItem.status == STARTED:
            p_portItem.setData(int(0))
        trialsorder.addData('p_portItem.started', p_portItem.tStart)
        trialsorder.addData('p_portItem.stopped', p_portItem.tStop)
        if p_portN2.status == STARTED:
            p_portN2.setData(int(0))
        trialsorder.addData('p_portN2.started', p_portN2.tStart)
        trialsorder.addData('p_portN2.stopped', p_portN2.tStop)
        if p_portC.status == STARTED:
            p_portC.setData(int(0))
        trialsorder.addData('p_portC.started', p_portC.tStart)
        trialsorder.addData('p_portC.stopped', p_portC.tStop)
        if p_portN3.status == STARTED:
            p_portN3.setData(int(0))
        trialsorder.addData('p_portN3.started', p_portN3.tStart)
        trialsorder.addData('p_portN3.stopped', p_portN3.tStop)
        if p_portType.status == STARTED:
            p_portType.setData(int(0))
        trialsorder.addData('p_portType.started', p_portType.tStart)
        trialsorder.addData('p_portType.stopped', p_portType.tStop)
        if p_port_2.status == STARTED:
            win.callOnFlip(p_port_2.setData, int(0))
        trialsorder.addData('p_port_2.started', p_port_2.tStart)
        trialsorder.addData('p_port_2.stopped', p_port_2.tStop)
        # the Routine "trial_1" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # ------Prepare to start Routine "ITI"-------
        continueRoutine = True
        routineTimer.add(1.000000)
        # update component parameters for each repeat
        # keep track of which components have finished
        ITIComponents = [fixationBreak]
        for thisComponent in ITIComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        ITIClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        
        # -------Run Routine "ITI"-------
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = ITIClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=ITIClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *fixationBreak* updates
            if fixationBreak.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                fixationBreak.frameNStart = frameN  # exact frame index
                fixationBreak.tStart = t  # local t and not account for scr refresh
                fixationBreak.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(fixationBreak, 'tStartRefresh')  # time at next scr refresh
                fixationBreak.setAutoDraw(True)
            if fixationBreak.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > fixationBreak.tStartRefresh + 1.0-frameTolerance:
                    # keep track of stop time/frame for later
                    fixationBreak.tStop = t  # not accounting for scr refresh
                    fixationBreak.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(fixationBreak, 'tStopRefresh')  # time at next scr refresh
                    fixationBreak.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in ITIComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "ITI"-------
        for thisComponent in ITIComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        trialsorder.addData('fixationBreak.started', fixationBreak.tStartRefresh)
        trialsorder.addData('fixationBreak.stopped', fixationBreak.tStopRefresh)
        thisExp.nextEntry()
        
    # completed 1.0 repeats of 'trialsorder'
    
    
    # ------Prepare to start Routine "break_2"-------
    continueRoutine = True
    routineTimer.add(31.000000)
    # update component parameters for each repeat
    # keep track of which components have finished
    break_2Components = [text_3, text_4]
    for thisComponent in break_2Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    break_2Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "break_2"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = break_2Clock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=break_2Clock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_3* updates
        if text_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_3.frameNStart = frameN  # exact frame index
            text_3.tStart = t  # local t and not account for scr refresh
            text_3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_3, 'tStartRefresh')  # time at next scr refresh
            text_3.setAutoDraw(True)
        if text_3.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_3.tStartRefresh + 30-frameTolerance:
                # keep track of stop time/frame for later
                text_3.tStop = t  # not accounting for scr refresh
                text_3.frameNStop = frameN  # exact frame index
                win.timeOnFlip(text_3, 'tStopRefresh')  # time at next scr refresh
                text_3.setAutoDraw(False)
        
        # *text_4* updates
        if text_4.status == NOT_STARTED and tThisFlip >= 30-frameTolerance:
            # keep track of start time/frame for later
            text_4.frameNStart = frameN  # exact frame index
            text_4.tStart = t  # local t and not account for scr refresh
            text_4.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_4, 'tStartRefresh')  # time at next scr refresh
            text_4.setAutoDraw(True)
        if text_4.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_4.tStartRefresh + 1.0-frameTolerance:
                # keep track of stop time/frame for later
                text_4.tStop = t  # not accounting for scr refresh
                text_4.frameNStop = frameN  # exact frame index
                win.timeOnFlip(text_4, 'tStopRefresh')  # time at next scr refresh
                text_4.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in break_2Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "break_2"-------
    for thisComponent in break_2Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    blockorder.addData('text_3.started', text_3.tStartRefresh)
    blockorder.addData('text_3.stopped', text_3.tStopRefresh)
    blockorder.addData('text_4.started', text_4.tStartRefresh)
    blockorder.addData('text_4.stopped', text_4.tStopRefresh)
    thisExp.nextEntry()
    
# completed 1.0 repeats of 'blockorder'


# ------Prepare to start Routine "bye"-------
continueRoutine = True
# update component parameters for each repeat
# keep track of which components have finished
byeComponents = [textBye]
for thisComponent in byeComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
byeClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "bye"-------
while continueRoutine:
    # get current time
    t = byeClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=byeClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *textBye* updates
    if textBye.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        textBye.frameNStart = frameN  # exact frame index
        textBye.tStart = t  # local t and not account for scr refresh
        textBye.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(textBye, 'tStartRefresh')  # time at next scr refresh
        textBye.setAutoDraw(True)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in byeComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "bye"-------
for thisComponent in byeComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('textBye.started', textBye.tStartRefresh)
thisExp.addData('textBye.stopped', textBye.tStopRefresh)
# the Routine "bye" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv', delim='auto')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
